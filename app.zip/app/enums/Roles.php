<?php

namespace App\Enums;


class  Roles
{
    /**
     * @var string
     */
    const ADMIN = 'admin';

    /**
     * @var string
     */
    const CUSTOMER = 'customer';
}
